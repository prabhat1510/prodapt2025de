class Employee:
    def __init__(self,name,age,position,email):
        self.name=name
        self.age=age
        self.position=position
        self.email=email
        
    #Class method to create an employee instace from user input
    @classmethod
    def from_user_input(cls):
        name= input("Enter employee name :")
        age= int(input("Enter employee age :"))
        position= input("Enter employee position :")
        email= input("Enter employee email :")
        #Creating and returning a new employee instance with user provided values
        return cls(name,age,position,email)