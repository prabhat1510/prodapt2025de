#Importing the 'pymongo' module for MongoDB interaction
import pymongo
class DatabaseManager:
    #Constructor method to initialize the db connection
    def __init__(self):
        #Initialize the client variable to None
        
        #client=None
        try:
            #Creating a MongoClient to connect to the local MongoDB server
            client=pymongo.MongoClient('mongodb://localhost:27017/')
            #Getting the mongodb database from the MongoDB server
            self.db=client['newtelcomdb']
            #Getting the employees collection from mongodb database
            self.collection =self.db['employees']
          
        except Exception as e:
            print("Error : ",e)
        '''
        finally:
            #Close the MongoDB client if it was intialized
            if self.client is not None:
                self.client.close()
                print("Conncetion closed")'''
    def fetch_all(self):
        data =self.collection.find()
        return data
    def insert(self,employee):
        data={
            'name':employee.name,
            'age':employee.age,
            'position':employee.position,
            'email':employee.email
        }
        #Insert
        eid=self.collection.insert_one(data).inserted_id
        print("Data inserted with id : ",eid)
        
    #Method to fetch a specific employee data based on name
    def fetch_one(self,name):
        data=self.collection.find_one({'name':name})
        return data
    
    #Delete
    def delete(self,name):
        self.collection.delete_one({'name':name})
        
    #update
    def update(self,name,employee):
        #Create a dictionary with updated employee details
        data={
            'name':employee.name,
            'age':employee.age,
            'position':employee.position,
            'email':employee.email
        }
        #Updating the employee data in employees collection
        self.collection.update_one({'name':name},{"$set":data})
                
        