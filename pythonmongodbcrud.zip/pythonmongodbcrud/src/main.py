from employee import Employee
from databasemanager import DatabaseManager

#Creating an instance of the DatabaseManager
database=DatabaseManager()

#Main function for the program
def main():
    while True:
        print("Options:")
        print("Press[1] for insert an employee")
        print("Press[2] for show all the employees")
        print("Press[3] for show specific employee")
        print("Press[4] for update an employee")
        print("Press[5] for delete an employee")
        print("Press[6] for exit.")
        try:
            #Taking employee input for their choice
            choice=int(input("Action: "))
            if choice == 1:
                employee=Employee.from_user_input()
                
                database.insert(employee)
            elif choice == 2:
                print("Choice 2")
                print(database)
                data = database.fetch_all()
                print(data)
                for employee in data:
                    print(employee)
            elif choice == 3:
                name=input("Enter the employee name ")
                data=database.fetch_one(name)
                if data is None:
                    print("Employee with name "+name+ " is not present")
                else:
                    print(data)
            elif choice == 4:
                name=input("Enter the employee name ")
                update_employee=Employee.from_user_input()
                database.update(name,update_employee)
                print("Employee updated successfully")
            elif choice == 5:
                name=input("Enter the employee name ")
                database.delete(name)
                print("Employee deleted successfully")
            elif choice == 6:
                break
            else:
                print("Invalid option key ! Please try again!")
        except Exception as e:
            print(e)
            print("Invalid employee Please try again")

#Entry point of the program
if __name__ == "__main__":
    main()